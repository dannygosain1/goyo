var searchData=
[
  ['reserved1',['reserved1',['../structfat__boot.html#affa7e6efb3ccea19ba7ea0ddadce7463',1,'fat_boot::reserved1()'],['../structfat32__boot.html#a7075c3c00aae071110fd1acb2e6fd599',1,'fat32_boot::reserved1()'],['../structfat32__fsinfo.html#ac24bd4801a60a54e5133ed1bb71bcdaa',1,'fat32_fsinfo::reserved1()']]],
  ['reserved2',['reserved2',['../structfat32__fsinfo.html#a9ec0e2756cd7e169268798a558df3814',1,'fat32_fsinfo']]],
  ['reservednt',['reservedNT',['../structdirectory_entry.html#afe7d00be85f3b78549b21610050da52b',1,'directoryEntry']]],
  ['reservedsectorcount',['reservedSectorCount',['../structbios_parm_block.html#adb4830c345b27293c7d7b97b77f52e01',1,'biosParmBlock::reservedSectorCount()'],['../structfat__boot.html#a13f272a8f780fb43a400f873a3fd7b73',1,'fat_boot::reservedSectorCount()'],['../structfat32__boot.html#a8e490f05ad3552dfbdf8f9332d287ba0',1,'fat32_boot::reservedSectorCount()']]],
  ['right',['right',['../classios__base.html#aec064a12730b5d87e718c1864e29ac64',1,'ios_base']]],
  ['rootdirentrycount',['rootDirEntryCount',['../structbios_parm_block.html#a9a1b24bb2dbb3a123c4ffc703954d71d',1,'biosParmBlock::rootDirEntryCount()'],['../structfat__boot.html#a2124f89e12307df944f08e6657dbf4af',1,'fat_boot::rootDirEntryCount()'],['../structfat32__boot.html#a94185496fb56c6e0e8078fc3803e9142',1,'fat32_boot::rootDirEntryCount()']]]
];
